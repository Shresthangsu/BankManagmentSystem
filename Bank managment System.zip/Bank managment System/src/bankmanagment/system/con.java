package bankmanagment.system;

import java.sql.*;

public class con {
    Connection c;
    Statement s;

    public con() {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection to the database
            c = DriverManager.getConnection("jdbc:mysql:///bankmanagementsystem", "root", "shres@2002");

            // Create a statement object to execute queries
            s = c.createStatement();

        } catch (Exception e) {
            e.printStackTrace(); // Print detailed error information
        }
    }
}

